import { env } from 'cloudflare:workers';
import { NextRequest, NextResponse } from 'next/server';
import { gameLog, validLogToken } from '../../../lib/game-log.mjs';

export const runtime = 'edge';
const reply = (body: unknown, status = 200) => NextResponse.json(body, { status,
  headers: { 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' } });
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

export async function GET(request: NextRequest) {
  if (!await validLogToken(request.headers.get('x-avalon-log-token'), env.LOG_SYNC_TOKEN))
    return reply({ error: '로그 동기화 인증이 필요합니다.' }, 401);
  try {
    const query = new URL(request.url).searchParams;
    const id = query.get('id');
    if (id) {
      if (!uuid.test(id)) return reply({ error: '잘못된 게임 코드입니다.' }, 400);
      const row = await env.DB!.prepare("SELECT state FROM games WHERE id = ? AND json_extract(state, '$.phase') = 'ENDED'")
        .bind(id).first<{ state: string }>();
      if (!row) return reply({ error: '저장 대상 게임이 없습니다.' }, 404);
      return reply(await gameLog(env.DB!, JSON.parse(row.state)));
    }
    const after = query.get('after') ?? '';
    if (after && !uuid.test(after)) return reply({ error: '잘못된 페이지 코드입니다.' }, 400);
    // ponytail: list completed/restarted games, then download only changed revisions; no archive table needed.
    const rows = await env.DB!.prepare("SELECT g.id, g.version, g.updated_at, COALESCE((SELECT MAX(f.id) FROM ai_failures f WHERE f.game_id=g.id),0) AS failure_id FROM games g WHERE json_extract(g.state, '$.phase') = 'ENDED' AND g.id > ? ORDER BY g.id LIMIT 50")
      .bind(after).all<{ id: string; version: number; updated_at: string; failure_id: number }>();
    return reply({ games: rows.results, next: rows.results.length === 50 ? rows.results.at(-1)!.id : null });
  } catch {
    return reply({ error: '게임 로그를 읽지 못했습니다.' }, 503);
  }
}
